
public class Outstate extends Student {
	private boolean tristate;
	
	public Outstate (boolean tristate, String fname, String lname, int credit)
	{
		super(fname, lname, credit);
		this.tristate = tristate;
	}

	@Override
	public int tuitionDue() 
	{
		int creditDue = credit;
		if(credit > MAXCREDITS)
		{
			creditDue = MAXCREDITS;
		}
		
		int fee;
		if(credit < MINFULLTIMECREDITS)
		{
			fee = PARTTIMEFEE;
		}
		else
		{
			fee = FULLTIMEFEE;
		}
		
		int discount = 0;
		if(tristate && (credit >= MINFULLTIMECREDITS))
		{
			discount = OUTOFSTATEDISCOUNTRATE * creditDue;
		}
		
		return ((OUTOFSTATETUITIONPERCREDIT * creditDue) + fee - discount);
	}
	
	@Override
	public String toString()
	{
		String strTristate;
		if(tristate)
		{
			strTristate = "Yes";
		}
		else
		{
			strTristate = "No";
		}
		return (super.toString() + " Tristate: " + strTristate + ". Tuition due: $" + tuitionDue());
	}
	
	public static void main(String [] args)
	{
		Outstate student1 = new Outstate(true, "Mark", "Barkalow", 12);
		if(student1.tuitionDue() == 8113)
		{
			System.out.println("Success student1");
		}
		Outstate student2 = new Outstate(false, "Jeremy", "Barkalow", 11);
		if(student2.tuitionDue() == 9162)
		{
			System.out.println("Success student2");
		}
		Outstate student3 = new Outstate(false, "John", "Smith", 18);
		if(student3.tuitionDue() == 12781)
		{
			System.out.println("Success student3");
		}
		Outstate student4 = new Outstate(true, "John", "Doe", 11);
		if(student4.tuitionDue() == 9162)
		{
			System.out.println("Success student4");
		}
		Outstate student5 = new Outstate(false, "Kim", "Smith", 15);
		if(student5.tuitionDue() == 12781)
		{
			System.out.println("Success student5");
		}
		
		System.out.println(student1 + "\n" + student2 + "\n" + student3 + "\n" + student4 + "\n" + student5);
	}
}
