
public class Instate extends Student {
	private int funds;
	
	public Instate(int funds, String fname, String lname, int credit)
	{
		super(fname, lname, credit);
		this.funds = funds;
	}

	@Override
	public int tuitionDue() 
	{
		int fundsDue = funds;
		int creditDue = credit;
		if(credit > MAXCREDITS)
		{
			creditDue = MAXCREDITS;
		}
		
		int fee;
		if(credit < MINFULLTIMECREDITS)
		{
			fee = PARTTIMEFEE;
			fundsDue = 0;
		}
		else
		{
			fee = FULLTIMEFEE;
		}
	
		return ((INSTATETUITIONPERCREDIT * creditDue) + fee - fundsDue);
	}
	
	@Override
	public String toString()
	{
		return (super.toString() + " Funds: " + funds + ". Tuition due: $" + tuitionDue());
	}
	
	public static void main(String [] args)
	{
		Instate student1 = new Instate(1000, "Mark", "Barkalow", 12);
		if(student1.tuitionDue() == 5637)
		{
			System.out.println("Success student1");
		}
		Instate student2 = new Instate(1000, "Jeremy", "Barkalow", 11);
		if(student2.tuitionDue() == 5609)
		{
			System.out.println("Success student2");
		}
		Instate student3 = new Instate(1000, "John", "Smith", 18);
		if(student3.tuitionDue() == 6936)
		{
			System.out.println("Success student3");
		}
		
		System.out.println(student1 + "\n" + student2 + "\n" + student3);
	}
}
